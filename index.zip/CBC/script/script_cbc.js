// #Cifrando CBC
function encrypt(){
    var data = document.getElementById('entrada').value;
    var key = CryptoJS.enc.Base64.parse(document.getElementById('key').value);
    var iv = CryptoJS.enc.Hex.parse(document.getElementById('iv').value);

    var enc = CryptoJS.AES.encrypt(
        data, key, {
            iv: iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        }

);
        // -----------------------------------------
        document.getElementById('saida').value = enc;
        console.log("Cifrado => " + enc)
};
///-------------------------------------------------------------------///

function decrypt(){    
    var data = document.getElementById('entrada').value;
    var key = CryptoJS.enc.Base64.parse(document.getElementById('key').value);
    var iv = CryptoJS.enc.Hex.parse(document.getElementById('iv').value);
        
    var dec = CryptoJS.AES.decrypt(
        data, key, {
            iv: iv,
            mode: CryptoJS.mode.CBC,
            padding: CryptoJS.pad.Pkcs7
        }
);
        var data_dec = dec.toString(CryptoJS.enc.Utf8);
        document.getElementById('saida').value = data_dec;
        console.log("Decifrado => " + data_dec);
};
    ///-------------------------------------------------------------------///