// #Cifrando AES.
function encrypt() {
    var data = document.getElementById('entrada').value;
    var key = document.getElementById('key').value;
	
	enc = CryptoJS.AES.encrypt(data, key);
	document.getElementById('saida').value = enc.toString();
};

// #Decifrando AES.
function decrypt(){    
    var data = document.getElementById('entrada').value;
    var key = document.getElementById('key').value;
	
	dec = CryptoJS.AES.decrypt(data, key);
	document.getElementById('saida').value = dec.toString(CryptoJS.enc.Utf8);
};