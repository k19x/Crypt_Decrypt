// #BASE64 Cifrando.
function encrypt(){
    var data = document.getElementById('entrada').value;
    var enc = btoa(data);
    document.getElementById('saida').value = enc;
	console.log("Cifrado: "+enc);

};

//#BASE64 Decifrando.
function decrypt(){    
    var data = document.getElementById('entrada').value;
    var dec = atob(data);
    document.getElementById('saida').value = dec;
	console.log("Decifrado: "+dec);
};